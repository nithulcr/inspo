import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  pageExtensions: ['ts', 'tsx', 'js', 'jsx', 'md', 'mdx'],
  distDir: '.next',
  experimental: {
    appDir: true,
    // Explicitly set the pages directory for Pages Router
    // This might be redundant if 'src/pages' is already the default,
    // but it ensures Next.js knows where to look for Pages Router routes.
    pagesDir: './src/pages',
  },
  webpack: (config, { isServer }) => {
    if (isServer) {
      config.externals.push('validator');
    }
    return config;
  },
  /* config options here */
};

export default nextConfig;