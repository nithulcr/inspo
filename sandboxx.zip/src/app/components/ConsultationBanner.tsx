"use client";
import Link from "next/link";
import { useLang } from "../hooks/useLang";

export default function ConsultationBanner() {
    const { isArabic } = useLang();
    return (
        <section className=" w-full max-w-7xl px-6 mx-auto ">
            <div className="bg-[var(--green2)] rounded-3xl w-full max-w-7xl mx-auto grid gap-8  lg:grid-cols-2 p-8 lg:py-16 lg:px-12  my-8 text-white">
                <div className="flex-1 text-left content-center">
                    <h3 className="font-medium text-xl md:text-2xl text-center">
                        {isArabic ? "دعنا نطلب موعدًا لاستشارة مجانية" : "Let’s Request A Schedule For Free Consultation"}
                    </h3>
                </div>
                <div className="grid  md:grid-cols-2 gap-8">
                    <div className="flex items-center gap-3 justify-center">
                        <svg width="50" height="50" viewBox="0 0 68 68" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21.9332 45.6849C15.9294 39.6695 11.3123 32.4152 8.40475 24.4292C6.80513 20.063 8.27075 15.2669 11.5593 11.9784L13.5945 9.94602C14.1416 9.39779 14.7915 8.96284 15.5069 8.66607C16.2223 8.36931 16.9893 8.21655 17.7638 8.21655C18.5384 8.21655 19.3053 8.36931 20.0207 8.66607C20.7362 8.96284 21.386 9.39779 21.9332 9.94602L26.6985 14.7114C27.2468 15.2585 27.6817 15.9084 27.9785 16.6238C28.2753 17.3393 28.428 18.1062 28.428 18.8807C28.428 19.6553 28.2753 20.4222 27.9785 21.1377C27.6817 21.8531 27.2468 22.503 26.6985 23.0501L25.526 24.2226C25.0567 24.6918 24.6844 25.2489 24.4304 25.862C24.1764 26.4751 24.0457 27.1323 24.0457 27.7959C24.0457 28.4596 24.1764 29.1167 24.4304 29.7299C24.6844 30.343 25.0567 30.9 25.526 31.3693L36.246 42.0921C36.7153 42.5614 37.2723 42.9337 37.8855 43.1877C38.4986 43.4417 39.1557 43.5724 39.8194 43.5724C40.483 43.5724 41.1402 43.4417 41.7533 43.1877C42.3664 42.9337 42.9235 42.5614 43.3927 42.0921L44.568 40.9196C45.1151 40.3713 45.765 39.9364 46.4805 39.6396C47.1959 39.3428 47.9628 39.1901 48.7374 39.1901C49.5119 39.1901 50.2788 39.3428 50.9943 39.6396C51.7097 39.9364 52.3596 40.3713 52.9067 40.9196L57.6721 45.6849C58.2203 46.2321 58.6553 46.8819 58.952 47.5974C59.2488 48.3128 59.4016 49.0797 59.4016 49.8543C59.4016 50.6288 59.2488 51.3958 58.952 52.1112C58.6553 52.8266 58.2203 53.4765 57.6721 54.0236L55.6398 56.056C52.3512 59.3474 47.5551 60.813 43.1889 59.2134C35.2029 56.3058 27.9486 51.6887 21.9332 45.6849Z" stroke="white" strokeWidth="3" strokeLinejoin="round" />
                        </svg>

                        <div>
                            <div className="text-xs text-gray-200">{isArabic ? "اتصل للمزيد من المعلومات" : "Call For More Info"}</div>
                            <div className="font-semibold text-lg lg:text-xl mt-2 tracking-wide" style={{ direction: "ltr", unicodeBidi: "bidi-override" }}>
                               0966 920032359
                            </div>
                        </div>
                    </div>
                    <Link href={isArabic ? "/ContactUs" : "/en/ContactUs"} className="justify-items-center content-center">
                        <button className="border border-white rounded-full px-6 py-3 flex items-center gap-2 text-white transition-transform duration-300 hover:scale-105 cursor-pointer">
                            {isArabic ? "اقرأ المزيد" : "Read more"}
                            <svg width="20" height="20" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fillRule="evenodd" clipRule="evenodd" d="M13.4768 5.51109C13.6175 5.37064 13.8081 5.29175 14.0068 5.29175C14.2056 5.29175 14.3962 5.37064 14.5368 5.51109L20.5368 11.5111C20.6773 11.6517 20.7562 11.8423 20.7562 12.0411C20.7562 12.2398 20.6773 12.4305 20.5368 12.5711L14.5368 18.5711C14.4682 18.6448 14.3854 18.7039 14.2934 18.7449C14.2014 18.7859 14.1021 18.8079 14.0014 18.8097C13.9007 18.8115 13.8006 18.7929 13.7072 18.7552C13.6138 18.7175 13.529 18.6613 13.4578 18.5901C13.3866 18.5189 13.3304 18.4341 13.2927 18.3407C13.255 18.2473 13.2365 18.1473 13.2382 18.0466C13.24 17.9459 13.2621 17.8465 13.3031 17.7545C13.344 17.6625 13.4031 17.5797 13.4768 17.5111L18.1968 12.7911H4.00684C3.80792 12.7911 3.61716 12.7121 3.47651 12.5714C3.33585 12.4308 3.25684 12.24 3.25684 12.0411C3.25684 11.8422 3.33585 11.6514 3.47651 11.5108C3.61716 11.3701 3.80792 11.2911 4.00684 11.2911H18.1968L13.4768 6.57109C13.3364 6.43046 13.2575 6.23984 13.2575 6.04109C13.2575 5.84234 13.3364 5.65171 13.4768 5.51109Z" fill="white" />
                            </svg>

                        </button>
                    </Link>
                </div>
            </div>

        </section>
    );
}
